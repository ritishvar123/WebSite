Thanks for downloading this theme!

Theme Name: Bocor
Theme URL: https://bootstrapmade.com/bocor-bootstrap-template-nice-animation/
Author: BootstrapMade
Author URL: https://bootstrapmade.com